import { Component, OnInit } from '@angular/core';
import { MentorService } from '../mentor.service';
import { Observable } from 'rxjs';
import { Mentor } from '../mentor';

@Component({
  selector: 'app-mentor-profile',
  templateUrl: './mentor-profile.component.html',
  styleUrls: ['./mentor-profile.component.css']
})
export class MentorProfileComponent implements OnInit {

  mentordetails:Mentor
  username:string=window.localStorage.getItem("mentor");
  show:boolean=false
  constructor(private mentorService:MentorService) { }

  ngOnInit() {
      this.mentorService.getMentorProfile(this.username)
       .subscribe((data:Mentor)=>{
       this.createMentor(data)
       });
  }

  createMentor(data:Mentor){
      this.mentordetails=data;
      this.show=true;
  }

}
