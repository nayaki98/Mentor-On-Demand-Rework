import { Trainings } from './trainings';

describe('Trainings', () => {
  it('should create an instance', () => {
    expect(new Trainings()).toBeTruthy();
  });
});
