export class Technologies {
    id:number;
    name:string;
    TOC:string;
    duration:string;
    prerequites:string;
    start_time:string;
    mentor_id:string;
}
