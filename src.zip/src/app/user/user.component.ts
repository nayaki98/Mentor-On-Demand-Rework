import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  user:User;
  user1:User;
  username:string;
  password:string;
  constructor(private userService:UserService) { }

  ngOnInit() {
  }

  onSubmit(){
    console.log("submit user")
      this.userService.getUser(this.username,this.password)
         .subscribe((data:User)=>{console.log(data)
        this.createUser(data)});
      
  }

  createUser(data:User){
    this.user1=data;
    window.localStorage.setItem("user",this.user1.username);
  }
}
