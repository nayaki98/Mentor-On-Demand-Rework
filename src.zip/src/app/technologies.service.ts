import { Injectable } from '@angular/core';

import { Technologies } from './technologies';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Trainings } from './trainings';

@Injectable({
  providedIn: 'root'
})
export class TechnologiesService {
  private baseUrl='http://localhost:9085/api';
  constructor(private http:HttpClient) { }

  createTraining(technologies:Technologies):Observable<any>{
    return this.http.post<Technologies>(`${this.baseUrl}/trainings/create`,technologies);
  }

  getTrainings():Observable<any>{
    return this.http.get<Technologies>(`${this.baseUrl}/allTrainings`);
  }

  createUserTraining(technologies:Technologies,username:string):Observable<any>{
    console.log(username)
    return this.http.post<Technologies>(`${this.baseUrl}/trainings/create/${username}`,technologies);
  }

  getAllTrainings(username:string):Observable<any>{
    return this.http.get<Trainings>(`${this.baseUrl}/trainings/fetch/${username}`);
  }
  getProposedTrainings(username:string):Observable<any>{
    return this.http.get<Trainings>(`${this.baseUrl}/trainings/proposed/${username}`);
  }

  getMentorAllTrainings(username:string):Observable<any>{
    console.log(username)
    return this.http.get<Trainings>(`${this.baseUrl}/trainings/mentor/fetch/${username}`);
  }

  acceptTrainings(technologies:Trainings):Observable<any>{
    return this.http.post<Trainings>(`${this.baseUrl}/acceptTrainings`,technologies);
  }
}
