import { Component, OnInit, Input } from '@angular/core';
import { Technologies } from '../technologies';
import { TechnologiesService } from '../technologies.service';

@Component({
  selector: 'app-list-technologies',
  templateUrl: './list-technologies.component.html',
  styleUrls: ['./list-technologies.component.css']
})
export class ListTechnologiesComponent implements OnInit {
 @Input() technologies:Technologies;
  constructor(private technologiesService:TechnologiesService) { }

  ngOnInit() {
  }
 
  onSubmit(){
    this.technologiesService.createTraining(this.technologies)
       .subscribe((data:Technologies)=>{console.log(data)})
  }
}
